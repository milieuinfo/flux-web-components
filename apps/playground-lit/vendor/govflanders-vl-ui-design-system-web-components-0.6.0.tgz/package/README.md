# @govflanders/vl-ui-design-system-web-components

Native web components for the Flemish government design system, built with [Lit](https://lit.dev/) and TypeScript.

## ⚠️ Development Warning

**This package is in active development and is not ready for production use.** The major version 0.x indicates that breaking changes may occur frequently and the API is not yet stable. Please use this package only for testing and development purposes.

## 📦 Installation

To start using the library, install it via npm or yarn:

```bash
npm install @govflanders/vl-ui-design-system-web-components
```

or

```bash
yarn add @govflanders/vl-ui-design-system-web-components
```

## How to use a NPM access token

Create a `.npmrc` file in the root directory of your project and include the following configuration:

```shell
//registry.npmjs.org/:_authToken=${NPM_TOKEN}
```

⚠️ Important: Do not hardcode your access token in this file. The token is sensitive and must never be committed to version control or exposed publicly.

## 🔧 Usage

### Importing Web Components

Web components are built on web standards and can be used in any framework or vanilla JavaScript project. Simply import the component and use the custom element in your HTML.

```javascript
// Import a specific component
import '@govflanders/vl-ui-design-system-web-components/components/example';
```

```html
<!-- Use the component in your HTML -->
<vl-example label="Hello World"></vl-example>
```

### Importing All Components

```javascript
// Import all components at once
import '@govflanders/vl-ui-design-system-web-components';
```

### Importing CSS Themes

This package includes pre-built CSS files for different themes. You can import them directly into your project.

The following themes are available:

default themes:
- `light`  - Default theme
- `dark`   - Default dark theme

branded themes:
- `vo`
- `dz`
- `nb`

To use a theme, import the corresponding CSS file:

```javascript
// Example: Import the 'light' theme
import '@govflanders/vl-ui-design-system-web-components/themes/light.css';
```

### Importing Fonts

The design system includes the **Flanders Art** font family in multiple weights and styles. The fonts are automatically included when you import the CSS, but you can also import them directly:

```javascript
// Import fonts (automatically included with CSS)
import '@govflanders/vl-ui-design-system-web-components/css';
// Or
import '@govflanders/vl-ui-design-system-web-components/css/index.css';
```

**Available Font Families:**
- Flanders Art Sans
- Flanders Art Serif
- Flanders Art Italic

**Available Font Weights:** Light (300), Regular (400), Medium (500), Bold (700)

These fonts are served in modern formats (WOFF2 and WOFF) with `font-display: swap` for optimal performance and user experience.

### Custom Element Registration

By default, importing a component will automatically register it with the browser's custom element registry. However, you can also import the component class and register it manually with a custom name:

```javascript
// Import the component class without auto-registration
import { VlExample } from '@govflanders/vl-ui-design-system-web-components/components/example';

// Register with a custom element name
VlExample.define('my-custom-example');
```

```html
<!-- Now use your custom element name -->
<my-custom-example label="Hello World"></my-custom-example>
```

This approach is useful when:
- You need to avoid naming conflicts with existing custom elements
- You want to control when components are registered

### Framework Integration

#### Vanilla JavaScript / HTML

```html
<!DOCTYPE html>
<html>
<head>
  <script type="module">
    import '@govflanders/vl-ui-design-system-web-components/themes/light.css';
    import '@govflanders/vl-ui-design-system-web-components/components/example';
  </script>
</head>
<body>
  <vl-example label="Hello World"></vl-example>
</body>
</html>
```

#### React

> **Note:** React 19 includes [full support for custom elements](https://react.dev/blog/2024/04/25/react-19#support-for-custom-elements), making web components integration seamless. For earlier versions of React, you may need additional workarounds for properties and events. See the [React Web Components documentation](https://legacy.reactjs.org/docs/web-components.html) for more details.

```jsx
import '@govflanders/vl-ui-design-system-web-components/themes/light.css';
import '@govflanders/vl-ui-design-system-web-components/components/example';

function App() {
  return (
    <vl-example label="Hello World"></vl-example>
  );
}
```

#### Vue 3

> **Note:** Vue 3 has excellent support for web components. See the [Vue Web Components guide](https://vuejs.org/guide/extras/web-components.html) for configuration options and best practices.

```vue
<script setup>
import '@govflanders/vl-ui-design-system-web-components/themes/light.css';
import '@govflanders/vl-ui-design-system-web-components/components/example';
</script>

<template>
  <vl-example label="Hello World"></vl-example>
</template>
```

#### Angular

```typescript
// app.component.ts
import '@govflanders/vl-ui-design-system-web-components/themes/light.css';
import '@govflanders/vl-ui-design-system-web-components/components/example';

// app.module.ts - Add CUSTOM_ELEMENTS_SCHEMA
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';

@NgModule({
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
```

```html
<!-- app.component.html -->
<vl-example label="Hello World"></vl-example>
```

## 🌐 Documentation & Examples

### Storybook

Explore all available components and their variations in our Storybook:

- **Production**: Coming soon
- **Development**: Coming soon

### IDE autocomplete

This package ships a [Custom Elements Manifest](https://custom-elements-manifest.open-wc.org/) (`custom-elements.json`) plus IDE-specific autocomplete metadata for every `<vl-*>` tag and its attributes. Setup depends on your editor and whether you write Lit templates.

> Contributing to this package? See [`CONTRIBUTING.md`](./CONTRIBUTING.md#documenting-the-public-api-cem) for how the manifest is generated and kept in sync.

#### WebStorm / IntelliJ

Zero config. The `web-types.json` field in this package's `package.json` is auto-discovered from `node_modules` after `yarn install`. Restart the IDE once to index. Plain attributes show descriptions and types on hover and completion.

> **Known limitation:** WebStorm's HTML validator currently flags Lit binding sugar (`?attr=`, `.prop=`, `@event=`) inside `` html`...` `` tagged templates as "not allowed here". Autocomplete itself still works for plain attribute names; the diagnostic is cosmetic. You can suppress it via Settings → Editor → Inspections → HTML → "Unknown HTML tag attributes" if it bothers you.

#### VS Code

1. Add the following to your project's `.vscode/settings.json`:
   ```json
   {
     "html.customData": [
       "./node_modules/@govflanders/vl-ui-design-system-web-components/vscode.html-custom-data.json"
     ]
   }
   ```
2. **If you write Lit templates** (`` html`<vl-button>` ``), also install the [`runem.lit-plugin`](https://marketplace.visualstudio.com/items?itemName=runem.lit-plugin) VS Code extension. Without it, VS Code's HTML validator rejects Lit binding syntax (`?disabled=`, `.value=`, `@click=`) inside tagged templates as invalid attributes.

Reload the editor after either step.

## 🔗 Links

- [Flemish Government Design System](https://www.vlaanderen.be/vlaanderen-design-system)
- [Repository](https://bitbucket.org/vlaamseoverheid/vl-design-system-build)
- [Lit Documentation](https://lit.dev/)

## 🤝 Contributing

This is an internal package for the Flemish Government. If you're part of the team and/or want to contribute, please refer to the contributing docs for development guidelines.

## 🚀 Release & Deployment

For complete release and deployment information, see the [Releases documentation](https://www.vlaanderen.be/vlaanderen-design-system/releases) on the Flemish Government Design System website.
